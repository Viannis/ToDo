import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'seconPage.dart';
import 'localNotificationHelper.dart';

class LocalNotification extends StatefulWidget {
  @override
  _LocalNotificationState createState() => _LocalNotificationState();
}

class _LocalNotificationState extends State<LocalNotification> {
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();
  @override
  void initState(){
    super.initState();
    // initialise the plugin. app_icon needs to be a added as a drawable resource to the Android head project
    var initializationSettingsAndroid =
      new AndroidInitializationSettings('app_icon');
    var initializationSettingsIOS = new IOSInitializationSettings(
      onDidReceiveLocalNotification: onDidReceiveLocalNotification);
    var initializationSettings = new InitializationSettings(
      initializationSettingsAndroid, initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
      onSelectNotification: onSelectNotification);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
          body: Container(
        color:Colors.white,
        child:Center( 
          child:RaisedButton( 
            child:Text('Show'),
            onPressed: ()=> showOngoingNotification(flutterLocalNotificationsPlugin,title:'Title',body:'Body'),
          )
        )
      ),
    );
  }
            
  Future onSelectNotification(String payload) async{
    await Navigator.push(context, MaterialPageRoute(builder:(context)=>SeconPage(payload:payload)),);
  }
      
  Future onDidReceiveLocalNotification(int id, String title, String body, String payload) {
    onSelectNotification(payload);
  }
}