import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:to_do/todo_list.dart';
import 'package:to_do/todo_todo.dart';
import 'todo.dart';
import 'localNotification.dart';

void main(){
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp,DeviceOrientation.portraitDown]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:HomePage(),
    );
  }
}

class HomePage extends StatefulWidget{
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<ToDos> _userTodos = [ 
    // ToDos(id: DateTime.now().toString(),todoTitle: 'todo1',time: DateTime.now(),todoList: [ToDoToDo(id: DateTime.now().toString(),count: 0,time: DateTime.now(),todo: 'Nested Todo1',check: false),ToDoToDo(id: DateTime.now().toString(),count: 1,time: DateTime.now(),todo: 'Nested Todo2',check: true)]),
    // ToDos(id: DateTime.now().toString(),todoTitle: 'todo2',time: DateTime.now(),todoList: [ToDoToDo(id: DateTime.now().toString(),count: 0,time: DateTime.now(),todo: 'Nested Todo1',check: false)]),
  ];
  
  final myController = TextEditingController();

  @override
  void dispose() {
    myController.dispose();
    super.dispose();
  }

  void _addNewTodo(String todoTitle,DateTime time){
    final newTodo = ToDos( 
      todoTitle: todoTitle,
      time: time,
      id: DateTime.now().toString(),
      todoList: [],
      toDoPercent: 0.0
    );
    setState(() {
      _userTodos.add(newTodo); 
    });
  }

  void _promptAddTodoItem() {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return new AlertDialog(
        title: new TextField(
          controller: myController,
          decoration: InputDecoration( 
            labelText: 'Add a List'
          ),
        ),
        actions: <Widget>[
          new FlatButton(
            child: new Text('add'),
            onPressed: () {
              _addNewTodo(myController.text, DateTime.now());
              myController.clear();
              Navigator.of(context).pop();
            }
          ),
          new FlatButton(
            child: new Text('cancel'),
            onPressed: () {
              myController.clear();
              Navigator.of(context).pop();
            }
          )
        ]
      );
    }
  );  
}

  void _deleteTodo(String id) {
    setState((){
      _userTodos.removeWhere((td){
        return td.id == id;
      });
    });
  }

  void updateToDoPercent(ToDos toDos){
    setState((){
      int count1 = 0;
      double percent;
      if(toDos.todoList.length == 0){
        toDos.toDoPercent = 0.0;
      }
      else{
        for(int i = 0;i<toDos.todoList.length;i++){
          count1 += toDos.todoList[i].count;
        }
        percent = count1.toDouble() / toDos.todoList.length.toDouble();
        toDos.toDoPercent = percent;
      }
    });
  }

  void rename(ToDos todos,String todoTitle){
    setState(() {
      todos.todoTitle = todoTitle;
    });  
  }

  @override 
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height:800.0,
          decoration: BoxDecoration(
        // Box decoration takes a gradient
        gradient: LinearGradient(
          // Where the linear gradient begins and ends
          begin: Alignment.bottomRight,
          end: Alignment.topLeft,
          // Add one stop for each color. Stops should increase from 0 to 1
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            // Colors are easy thanks to Flutter's Colors class.
            Colors.purple[600],
            Colors.purple[500],
            Colors.purple[400],
            Colors.purple[300],
          ],
        ),
      ),
          child: Column(
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                width: double.infinity,
                margin:EdgeInsets.only(top:70.0),
                child: Text('ToDo',style:TextStyle(fontSize: 40.0,fontWeight: FontWeight.w800,color: Color.fromRGBO(204, 153, 255, 0.9)),textAlign: TextAlign.start,)),
              Divider(endIndent: 50.0,color: Color.fromRGBO(204, 153, 255, 0.7),thickness: 4.0,),
              Container(
                height:600.0,
                child: ToDoList(_userTodos, _deleteTodo,rename, updateToDoPercent),
              ),
              
            ],
            
          ),
        ),
      ),
      floatingActionButton: Row(
        children: <Widget>[
          FloatingActionButton(child:Text('Go'),onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => LocalNotification())
            );
          },),
          FloatingActionButton(child: Icon(Icons.add),onPressed: _promptAddTodoItem,),
        ],
      ),
    );
  }
}