import 'package:flutter/material.dart';

class SeconPage extends StatelessWidget {
  final String payload;

  const SeconPage({
    @required this.payload,
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child:Center(
        child:Column(
          children: <Widget>[ 
            Text(payload),
            RaisedButton(child:Text('Back'),onPressed: () => Navigator.pop(context)),
          ],
        )
      )
      
    );
  }
}