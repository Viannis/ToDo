import 'todo_todo.dart';

class ToDos{
  final String id;
  String todoTitle;
  final DateTime time;
  final List<ToDoToDo> todoList;
  double toDoPercent;
  // final ToDoToDo toDoToDo;

  ToDos({
    this.id,
    this.todoTitle,
    this.time,
    this.todoList,
    this.toDoPercent
  });
}

