import 'package:flutter/material.dart';
import 'package:to_do/Percentage.dart';
import 'todo.dart';
import 'todo_todo.dart';
import 'todo_todo_list.dart';
import 'del.dart';

class ToDoList extends StatefulWidget {
  final List<ToDos> todos;
  final Function deleteTodo;
  final Function rename;
  final Function updateTodopercent;
  

  ToDoList(this.todos, this.deleteTodo, this.rename, this.updateTodopercent);

  @override
  _ToDoListState createState() => _ToDoListState();
}

class _ToDoListState extends State<ToDoList> {
  Options selectedChoice = options[0];

  final myController = TextEditingController();

  // final List<ToDos> todoin = [ 
  //   // ToDoToDo(id: DateTime.now().toString(),todo: 'todo1',time: DateTime.now(),check: false,count:0),
  //   // ToDoToDo(id: DateTime.now().toString(),todo: 'todo2',time: DateTime.now(),check: false,count:0),
  // ];

  void _addNewTodoTodo(String todo,DateTime time,ToDos todos){
    final newTodoTodo = ToDoToDo( 
      todo: todo,
      time: time,
      id: DateTime.now().toString(),
      check: false,
      count: 0,
    );
    setState(() {
      todos.todoList.add(newTodoTodo);
      widget.updateTodopercent(todos);
    });
  }
  // void remove(String id){

  // }

  void _promptUpdateTodo(ToDos todos) {
    myController.text = todos.todoTitle;
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return new AlertDialog(
        
        title: new TextField(
         
          controller: myController,
          decoration: InputDecoration(
            labelText: 'Rename Todo'
          ),
        ),
        actions: <Widget>[
          new FlatButton(
            child: new Text('update'),
            onPressed: () {
              widget.rename(todos,myController.text);
              myController.clear();
              Navigator.of(context).pop();
            }
          ),
          new FlatButton(
            child: new Text('cancel'),
            onPressed: () {
              myController.clear();
              Navigator.of(context).pop();
            }
          )
        ]
      );
    }
  );  
}

   void _promptAddTodoTodoItem(ToDos todos) {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return new AlertDialog(
        title: new TextField(
          controller: myController,
          decoration: InputDecoration( 
            labelText: 'Add Todo'
          ),
        ),
        actions: <Widget>[
          new FlatButton(
            child: new Text('add'),
            onPressed: () {
              _addNewTodoTodo(myController.text, DateTime.now(),todos);
              myController.clear();
              Navigator.of(context).pop();
            }
          ),
          new FlatButton(
            child: new Text('cancel'),
            onPressed: () {
              myController.clear();
              Navigator.of(context).pop();
            }
          )
        ]
      );
    }
  );
  
  
}

  void _deleteTodoTodo(ToDos todos,String id) {
    setState((){
      todos.todoList.removeWhere((tid){
        return tid.id == id;
      });
    });
  }

  void renameTodo(ToDoToDo toDoToDo,String todo){
    setState(() {
      toDoToDo.todo = todo; 
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.todos.isEmpty ? Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.all(50.0),
          child: Text('No Todos Yet!',style: TextStyle(fontSize: 40.0,color: Color.fromRGBO(255, 220, 222, 0.4),fontWeight: FontWeight.bold),)
        ),
        SizedBox(height: 20.0,),
        Container(
          height:200.0,
          child: Image.asset('assets/images/waiting.png', fit: BoxFit.cover,)
        )
      ],
    ) : ListView.builder( 
        scrollDirection: Axis.horizontal,
        itemBuilder: (ctx, index) {
          return Card( 
            elevation: 5.0,
            margin:EdgeInsets.all(50.0),
            shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(30.0)),
            child: Container( 
              width: 310.0,
              child: Column( 
                children: <Widget>[ 
                  Row(
                    children: <Widget>[
                      Container( 
                        padding: EdgeInsets.symmetric(horizontal: 30.0),
                        width: 200.0,
                        margin:EdgeInsets.only(top:30.0),
                        child: Text(widget.todos[index].todoTitle,style:TextStyle(fontWeight: FontWeight.bold,fontSize: 30.0),),
                      ),
                      Container(
                        margin:EdgeInsets.only(top:30.0),
                        child: IconButton(icon: Icon(Icons.add),onPressed: (){
                          _promptAddTodoTodoItem(widget.todos[index]);
                        },),
                      ),
                      Container(
                        margin:EdgeInsets.only(top:28.0),
                        child: PopupMenuButton(
                          
                          itemBuilder: (BuildContext context) {
                            return options.map((Options choice){
                              return new PopupMenuItem(
                                value: choice,
                                child: new ListTile( 
                                  title: choice.opt,
                                  leading: choice.ic,
                                ),
                              );
                            }).toList();
                          },
                          onSelected: (choice) {
                            choiceAction(choice,widget.todos[index].id,widget.todos[index]);
                          } ,
                        ),
                      )
                    ],
                  ),
                  
                  // Percentage(widget.todos[index],getPercent(widget.todos[index]),_counter),
                  Percentage(widget.todos[index].toDoPercent),
                  Container( 
                    margin:EdgeInsets.all(10.0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10.0),color:Colors.blue,),
                    height: 350.0,
                    
                    child:ToDoToDoList(widget.todos[index],_deleteTodoTodo,renameTodo,widget.updateTodopercent),
                    //ToDoToDoList(_userTodoTodo,_deleteTodoTodo)
                  ),
                  
                ],
              ),
            ),
          );
        },
        itemCount: widget.todos.length,
    );
  }
  void choiceAction(Options choice,String id,ToDos todos){
    print(id);
    setState(() {
      if(choice.opt.toString() == "Text(\"Delete\")"){
        widget.deleteTodo(id);
        print('Delete');
      }
      else if(choice.opt.toString() == "Text(\"Rename\")"){
        _promptUpdateTodo(todos);
        print('Rename');
      }
      else{ 
        print('Nothing');
      }
    });
  }

  double getPercent(ToDos todos){
    int count1 = 0;
    double percent;
    if(todos.todoList.length == 0){
      return 0.0;
    }
    else{
      for(int i = 0;i<todos.todoList.length;i++){
      count1 += todos.todoList[i].count;
    }
    percent = count1.toDouble() / todos.todoList.length.toDouble();
    return percent;
    }
    
    // print(count1.toString());
    // print((count1 / todos.todoList.length).toStringAsPrecision(1));
  }
  
}