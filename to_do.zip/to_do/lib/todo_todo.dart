class ToDoToDo{
  final String id;
  String todo;
  final DateTime time;
  bool check;
  int count;

  ToDoToDo({
    this.id,
    this.todo,
    this.time,
    this.check,
    this.count,
  });
}

