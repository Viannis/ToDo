import 'package:flutter/material.dart';
import 'todo_todo.dart';
import 'main.dart';
import 'todo.dart';
import 'opns.dart';
import 'package:intl/intl.dart';


class ToDoToDoList extends StatefulWidget {
  final ToDos todo;
  final Function deleteTodoTodo;
  final Function renameTodo;
  final Function updateToDoPercent;

  ToDoToDoList(this.todo,this.deleteTodoTodo,this.renameTodo,this.updateToDoPercent);

  @override
  _ToDoToDoListState createState() => _ToDoToDoListState();
}

class _ToDoToDoListState extends State<ToDoToDoList> {
  // void change(bool ch){
  //   setState(() {
  //     ch = !ch;
  //   });
  // }
  
  final myController = TextEditingController();

  void showTextCard(ToDoToDo toDoToDo){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return new AlertDialog( 
          content: Container(
            child: Text(DateFormat.yMMMd().format(toDoToDo.time),style:TextStyle(fontSize: 15.0,color:Colors.grey),),
          ),
          title: Text(toDoToDo.todo,style: TextStyle(fontSize: 40.0,fontWeight: FontWeight.bold,color:Colors.black),),
          titlePadding: EdgeInsets.all(20.0),
        );
      }
    );
  }

  void _promptUpdateTodoTodo(ToDoToDo todos) {
    myController.text = todos.todo;
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return new AlertDialog(
        
        title: new TextField(
         
          controller: myController,
          decoration: InputDecoration(
            labelText: 'Edit Todo'
          ),
        ),
        actions: <Widget>[
          new FlatButton(
            child: new Text('update'),
            onPressed: () {
              widget.renameTodo(todos,myController.text);
              myController.clear();
              Navigator.of(context).pop();
            }
          ),
          new FlatButton(
            child: new Text('cancel'),
            onPressed: () {
              myController.clear();
              Navigator.of(context).pop();
            }
          )
        ]
      );
    }
  );  
}

  @override
  Widget build(BuildContext context) {
    return widget.todo.todoList.isEmpty ? 
    Container(
      width:double.infinity,
      child:Column( 
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(30.0),
            child: Text('No ToDos Yet!',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 30.0,color: Colors.lightGreenAccent),),
          ),
          SizedBox(height: 10.0,),
          Container(
            padding: EdgeInsets.all(20.0),
            height:200.0,
            child: Image.asset('assets/images/waiting.png', fit: BoxFit.cover,)
          ),
        ],
      ), 
    ) : ListView.builder(
      itemCount: widget.todo.todoList.length,
      itemBuilder: ((ctx,index){
         
        return Card( 
          elevation: 5.0,
          margin:EdgeInsets.only(left:10.0,right:10.0,bottom:5.0,top:5.0),
          child:ListTile(
            onLongPress: (){
              showTextCard(widget.todo.todoList[index]);
            }, 
            leading: Checkbox( 
              value: widget.todo.todoList[index].check,
              onChanged: (bool value){
                setState(() {
                   widget.todo.todoList[index].check = value;
                   if(widget.todo.todoList[index].check){
                     
                     print('true');
                     widget.todo.todoList[index].count = 1;
                     widget.updateToDoPercent(widget.todo);
                   }
                   else{
                     print('false');
                     widget.todo.todoList[index].count = 0;
                     widget.updateToDoPercent(widget.todo);
                   }

                });
                
              },
            ),
            title: Container(child: Text(widget.todo.todoList[index].todo,style:TextStyle(fontWeight: FontWeight.bold,fontSize: 18.0))),
            trailing: PopupMenuButton(
              itemBuilder: (BuildContext context) {
                return options.map((Opns choice){
                  return new PopupMenuItem(
                    value: choice,
                    child: new ListTile( 
                      title: choice.opt,
                      leading: choice.ic,
                    ),
                  );
                }).toList();
              },
              onSelected: (choice) {
                choiceSelect(choice,widget.todo,widget.todo.todoList[index].id,widget.todo.todoList[index]);
              } ,
            ),
            //widget.todo[index].check ? IconButton(icon:Icon(Icons.check_box),onPressed: () => change(widget.todo[index].check)) : IconButton(icon: Icon(Icons.check_box_outline_blank),onPressed: () => widget.todo[index].check = !widget.todo[index].check),
          )
        );
      }),
      
    );
  }
  void choiceSelect(Opns choice,ToDos todos,String id,ToDoToDo todo){
    print(id);
    setState(() {
      if(choice.opt.toString() == "Text(\"Delete\")"){
        widget.deleteTodoTodo(todos,id);
        print('Delete');
      }
      else if(choice.opt.toString() == "Text(\"Edit\")"){
        _promptUpdateTodoTodo(todo);
        print('Edit');
      }
      else if(choice.opt.toString() == "Text(\"Remind\")"){ 
        print('Remind');
      }
      else{
        print('Nothing');
      }
    });
  }

  double getPer(ToDos todos){
    print('getPer');
    int count1 = 0;
    double percent;
    for(int i = 0;i<todos.todoList.length;i++){
      count1 += todos.todoList[i].count;
    }
    percent = count1.toDouble() / todos.todoList.length.toDouble();
    print(percent.toString());
    return percent;
  }
}